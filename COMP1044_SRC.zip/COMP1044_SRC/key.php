<!DOCTYPE html>
<html>
    <title>Enter Key</title>
    <link rel="icon" type="image/x-icon" href="image/godrive.jpeg"/>
    <link rel="stylesheet" href="key.css"/>
</html>

<body>
    <div class="createbox"> 
    <img class=logo src="image/logo2.PNG" alt="logo">
        <form method="POST" action="#">
            <h2> Add New Staff </h2>
            <div class="inputbox">
                <label for="key"> Enter Key: </label>
                <input type="password" name="key" placeholder="Enter key to create staff" >
            </div>
            <div class="confirmbutton">
                <input class="confirmb" type="submit" name="submit" value="Confirm">
            </div>
        </form>
    </div>
    <!--Only staff knows the key required to add new staff into the system, staff has to enter this key to verify themselves-->
    <script>
        const form = document.querySelector('form');
        const input = document.querySelector('input[name="key"]');
        const confirmButton = document.querySelector('.confirmb');

        form.addEventListener('submit', (event) => {
        event.preventDefault();
        if (input.value === '1234') {
            window.location.href = 'createstaff.php';
        } else {
            alert('Invalid key. Please try again.');
        }
        });

    </script>
</body>