<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title>Staff Activity</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="homepage2.css"/>
	<link rel="stylesheet" href="styles.css"/>
</head>
<style>
	/*table formatting*/
	body{
		align-self: center;
	}
	table{
	  width:100%;
	  border-collapse:separate;
	  border-spacing: 5 0px;
	}
	.tbl-header{
	font-family:'Montserrat', sans-serif;
	  background-color: white;
	  border-spacing: 20 0px;
	  align-content: left;
	  overflow-x:auto;
	 }
	.tbl-content{
      align-content: center;
	  height:300px;
	  overflow-x:auto;
	  margin-top: 0px;
	  border: 1px solid rgba(255,255,255,1);
	}
	th{
      width:30%;
      border-bottom: solid 1px rgba(255,255,255,1);
      background-color: rgba(255,255,255,0);
	  padding:20px;
	  font-family:'Montserrat', sans-serif;
	  text-align: center;
	  font-weight: 100;
	  font-size: 20px;
	  color: #1B244D;
	  width:230px;
	  text-transform: uppercase;
	}
	td{
	  padding:5px;
	  font-family:'Montserrat', sans-serif;
	  text-align: center;
	  vertical-align:center;
	  font-weight: 300;
	  font-size: 20px;
	  color: #1B244D;
	  border-bottom: solid 1px rgba(255,255,255,1);
	  width: 170px;
	}
</style>
<body>
	   <div class=navigation>
            <nav>
                <img class=navlogo src="image/logo.PNG" alt="Logo">
                <a href="homepage.php" class="home">Home</a>
                <a href="index1.php" class="mreservation" >Make Reservation</a>
                <a href="manage_page.php" class="reservation">Reservations</a>
				<a href="staff_activity.php" class="reservation">Staff Activity</a>
            </nav>

        <li class="dropdown"> <!--getting the user's actual name from loginpage.php to display on top right hand corner-->
            <?php $var=$_SESSION['getName']; ?>
            <img class=user src="image/V.png" alt="user"></img>
                <div><?php echo $var; ?></div>
                    <ul class="ddlist"> 
                        <li><a href="key.php">New Staff</a></li>
                        <li><a href="loginpage.php">Log Out</a></li>
                    </ul>
        </li>
        </div>
        
  <div class="page">
  	<div class="right">
	<table>
		<tr>
			<?php
			/*display all rows from the staff_activity table*/
					$conn = mysqli_connect("localhost","root","","COMP1044_database");
					if ($conn-> connect_error){
						die("Connection failed: ".$conn-> connect_error);
					}else{
						$sql = "SELECT * from staff_activity";
						$result=$conn-> query($sql);
					}
					if ($result-> num_rows >0){
						?><div class="tbl-header">
							<th><b>time</b></th>
							<th><b>date</b></th>
							<th><b>staff username</b></th>
							<th><b>action</b></th>
							<th><b>reservation ID</b></th>
							<th><b>customer ID</b></th>
						</tr><?php
						while ($row = $result-> fetch_assoc()){
							echo "<tr><td>".$row["recorded_time"]."</td><td>".$row["recorded_date"]."</td><td>".$row["staff_username"]."</td><td>".$row["action"]."</td><td>".$row["reservation_No"]."</td><td>".$row["customer_ID"]."</td></tr>";
						}
						echo "</table>";
					}else{
						echo "No staff activity yet.";
					}
			?>
	</div>
	</table>
</div>
</div>
</body>
</html>
