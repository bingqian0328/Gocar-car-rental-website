<?php include "functions1.php" ?>
<!DOCTYPE html>
<html>
    <head>
        <title>New Staff</title>
        <link rel="icon" type="image/x-icon" href="image/godrive.jpeg"/>
        <link rel="stylesheet" href="homepage2.css"/>
        <link rel="stylesheet" href="createstaff.css"/>
    </head>

<body>
    <div class="createbox"> 
        <img class=logo src="image/logo2.PNG" alt="logo">
        <form method="POST">
            <h2> Add New Staff </h2>
            <div class="inputbox">
                <label for="newname"> Enter your name: </label>
                <input type="text" name="newname" placeholder="Enter your full name" required>
            </div>
            <div class="inputbox">
                <label for="newusername"> Create username: </label>
                <input type="text" name="newusername" placeholder="Enter new username" required>
            </div>
            <div class="inputbox">
                <label for="newpassword"> Create password: </label>
                <input type="password" name="newpassword" placeholder="Create your password" required>
            </div>
            <div class="createbutton">
                <input class="createb" type="submit" name="submit" value="Create" required>
            </div>
        </form>
    </div>
<?php
session_start();
// set up database connection
$servername = "localhost"; // replace with your server name
$username = "root"; // replace with your database username
$password = ""; // replace with your database password
$dbname = "COMP1044_database"; // replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// insert staff details into staff_detail table
/*but first check if username entered is unique to the user*/
/*staffID is a primary key, username is a candidate key and a foreign key*/

if (isset($_POST['submit'])) {
?></div><?php
/*get user to input new username, their actual name and password*/
  $newname = $_POST['newname'];
  $newusername = $_POST['newusername'];
  $newpassword = $_POST['newpassword'];
  $exists = userNameExists($newusername);
  if ($exists===false){
    $sql = "INSERT INTO staff_detail (staff_name,staff_username, password)
              VALUES ('$newname','$newusername', '$newpassword')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>window.location.replace('homepage.php');</script>";
        exit();
    } else {
        echo "<script>alert('Failed to create');</script>";
        echo "<script>window.location.replace('createstaff.php');</script>";
        exit();
    }
  }else{
    /*alert user that their username is already used and prompt to reenter*/
    ?>
    <script>
        alert('Username already taken. Please enter another username.');
        event.preventDefault();
    </script>
    <?php
  }
  }

// close database connection
$conn->close();
?>
</body>

</html>
