<?php session_start(); include "functions1.php" ?>
<!DOCTYPE html>
<html>
<style>
    *{
    background-color: #1B244D;
}
</style>
    <head>
        <title> Homepage </title>
        <link rel="icon" type="image/x-icon" href="image/godrive.jpeg"/>
        <link rel="stylesheet" href="homepage2.css"/>
    </head>

    <body>
        <div class="body">

            <div class=navigation>
            <nav>
                    <img class=navlogo src="image/logo.PNG" alt="Logo">
                    <a href="homepage.php" class="home">Home</a>
                    <a href="index1.php" class="mreservation" >Make Reservation</a>
                    <a href="manage_page.php" class="reservation">Reservations</a>
                    <a href="staff_activity.php" class="reservation">Staff Activity</a>
            </nav>
            <li class="dropdown">
                <!--dropdown menu for top right corner showing options for adding new staff and logging out-->
                <?php $var=$_SESSION['getName']; ?>
                    <img class=user src="image/V.PNG" alt="user">
                    <div><?php echo $var; ?></div>
                        <ul class="ddlist"> 
                            <li><a href="key.php">New Staff</a></li>
                            <li><a href="loginpage.php">Log Out</a></li>
                        </ul>
            </li>
            </div>

            <div class="slideshow-container">
                <img class="mySlides" src="image/roadtrip.PNG" alt="roadtrip">
                <img class="mySlides" src="image/islandcar.PNG" alt="islandcar">
                <img class="mySlides" src="image/tesla.PNG" alt="tesla">
                <img class="mySlides" src="image/roadtrip.PNG" alt="roadtrip">

                <script>
                /* JavaScript for Slideshow */

                var slideIndex = 0;
                showSlides();

                function showSlides() {
                var i;
                var slides = document.getElementsByClassName("mySlides");
                for (i = 0; i < slides.length; i++) {
                    slides[i].style.display = "none";
                }
                slideIndex++;
                if (slideIndex > slides.length) {slideIndex = 1}
                slides[slideIndex-1].style.display = "block";
                setTimeout(showSlides, 5000); // Change image every 2 seconds
                }

                </script>
            </div>


            <div class="carsdisplay">
                <h3> Popular cars of the month</h3>

                <div class="carspic1">
                    <div class="car1">
                        <img src="image/ferrari.PNG" alt="ferrari">
                        <p>Ferrari F430 Scuderia Red</p>
                        <p>RM6000 per day</p>
                    </div>

                    <div class="car2">
                        <img src="image/bentley.PNG" alt="bentley">
                        <p>Bentley Continental Flying Spur White</p>
                        <p>RM4800 per day</p>
                    </div>
                
                    <div class="car3">
                        <img src="image/rollsroyce.PNG" alt="rollsroyce">
                        <p>Rolls Royce Phantom Blue</p>
                        <p>RM9800 per day</p>
                    </div>
                </div>

                <div class="carspic2">
                    <div class="car4">
                        <img src="image/lambo.PNG" alt="lambo">
                        <p>Lamborghini Murcielago LP640 Matte Black</p>
                        <p>RM7000 per day</p>
                    </div>

                    <div class="car5">
                        <img src="image/jaguar.PNG" alt="jaguar">
                        <p>Jaguar S Type Champagne</p>
                        <p>RM1350 per day</p>
                    </div>
                
                    <div class="car6">
                        <img src="image/porsche.PNG" alt="porsche">
                        <p>Porsche Boxster White</p>
                        <p>RM2800 per day</p>
                    </div>
                </div>

                <div class="booknow">
                    <form action="index1.php">
                    <input class="loginb" type="submit" name="submit" value="BOOK CAR NOW">
                    </form>
                </div>

                <div class="blankspace">
                    
                </div>
                
            </div>
        </div>

        



    </body>
</html>
