<?php
include "functions1.php";
session_start();
$host = "localhost";
$user="root";
$password="";
$db="COMP1044_database";

$conn = new mysqli($host, $user, $password, $db);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Clear error message
if (isset($_POST['staffuname'])) {

    $uname = $_POST['staffuname'];
    $_SESSION['getUserName'] = $uname; // send to reservations.php page to store in reservations and staff_activity table
    $password = $_POST['staffpassword'];
    $_SESSION['getName'] = getName($uname); // send actual name to the homepage

    if (StaffExists($uname,$password)==true) {
        header("Location: homepage.php");
        exit();
    } else {
        echo "<script>alert('Incorrect Login Details');</script>";
        echo "<script>window.location.replace('loginpage.php');</script>";
        exit();
    }
    
}
?>


<!DOCTYPE html>
<head>
    <title>Staff Login Page</title>
    <link rel="icon" type="image/x-icon" href="image/godrive.jpeg"/>
    <link rel="stylesheet" href="loginpage.css"/>
</head>

<body>
    <div class="loginbox"> 
        <img class=logo src="image/logo2.PNG" alt="logo">
        <form method="POST" action="#">
            <h2> Sign In </h2>
            <div class="inputbox">
                <label for="staffid"> Staff Username: </label>
                <input type="text" name="staffuname" placeholder="Enter your Staff username" >
            </div>
            <div class="inputbox">
                <label for="staffpassword"> Password: </label>
                <input type="password" name="staffpassword" placeholder="Enter your password">
            </div>
            <div class="loginbutton">
                <input class="loginb" type="submit" name="submit" value="LOGIN">
            </div>
        </form>
    </div>
</body>
</html>

