<?PHP
    $connect=mysqli_connect("localhost","root","","COMP1044_database");
?>