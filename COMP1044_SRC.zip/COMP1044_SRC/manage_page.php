<?PHP
session_start();
?>

<!DOCTYPE html>
    <head>
        <link rel="stylesheet" href="manage_page.css">
        <link rel="stylesheet" href="styles.css"/>
    <link rel="stylesheet" href="homepage2.css"/>
        <title>Manage Reservation</title>
        <link rel="icon" type="image/x-icon" href="image/godrive.jpeg">
    </head>
    <br><br>

<body>
    <div class=navigation>
                <nav>
                        <img class=navlogo src="image/logo.PNG" alt="Logo">
                        <a href="homepage.php" class="home">Home</a>
                        <a href="index1.php" class="mreservation" >Make Reservation</a>
                        <a href="manage_page.php" class="reservation">Reservations</a>
                        <a href="staff_activity.php" class="reservation">Staff Activity</a>
                </nav>
                <li class="dropdown">
                    <?php $var=$_SESSION['getName']; ?>
                        <img class=user src="image/V.PNG" alt="user">
                        <div><?php echo $var; ?></div>
                            <ul class="ddlist"> 
                                <li><a href="key.php">New Staff</a></li>
                                <li><a href="loginpage.php">Log Out</a></li>
                            </ul>
                </li>
            
    </div>
            <table id="customers">
    <tr>
            <th>Reservation Number</th>
            <th>Car ID</th>
            <th>Customer ID</th>
            <th>Starting Date</th>
            <th>Finishing Date</th>
            <th>Total Rate</th>
            <th>Choices</th>
    </tr>

<?PHP
include ('connection.php');
$selectAll = "select* from reservation";
$searchAll = mysqli_query($connect,$selectAll);
while ($record = mysqli_fetch_array($searchAll, MYSQLI_ASSOC))
{
    /*display all reservations with an extra column with header 'Choices' and each row will have an Edit and Delete button*/
    $_SESSION['reserve_No'] = $record['reservation_No'];
    $_SESSION['reserve_car_ID'] = $record['car_ID'];
    $_SESSION['reserve_customer_ID'] = $record['customer_ID'];
    $_SESSION['reserve_pickup_date'] = $record['starting_Date'];
    $_SESSION['reserve_return_date'] = $record['finishing_Date'];
    $_SESSION['reserve_total_rate'] = $record['total_rate'];
    echo"
    <tr>
        <td>".$_SESSION['reserve_No']."</td>
        <td>".$_SESSION['reserve_car_ID']."</td>
        <td>".$_SESSION['reserve_customer_ID']."</td>
        <td>".$_SESSION['reserve_pickup_date']."</td>
        <td>".$_SESSION['reserve_return_date']."</td>
        <td>"."RM ".$_SESSION['reserve_total_rate']."</td>
        <td>";
?>
    <form method="POST" action="">
        <button formaction="edit_booking.php" type="submit" name="edit_button" value="<?PHP echo $_SESSION['reserve_No']; ?>" class="button">EDIT</button>
        <button formaction="delete_booking.php" type="submit" name="delete_button" value="<?PHP echo $_SESSION['reserve_No']; ?>" class="button">DELETE</button>
    </form>
    <?PHP 
}
?>
</td>
</tr>
</table>
</body>