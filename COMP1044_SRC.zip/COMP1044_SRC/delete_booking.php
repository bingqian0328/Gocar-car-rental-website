<?PHP
session_start();
include "functions1.php";
$reservation_No=$_POST['delete_button'];
echo $reservation_No;
/*retrieve customer id to store in staff activity table before the record is deleted*/
$cust_id=getCustID($reservation_No);
include ('connection.php');
/*have to get customer id from reservations table to store in staff activity table*/
$getdelrec="SELECT * FROM `reservation` WHERE (`reservation_No`='$reservation_No')";
$deleteReservation = "DELETE FROM `reservation` WHERE `reservation_No`='$reservation_No'";

$runDelete = mysqli_query($connect,$deleteReservation);

if($runDelete==TRUE)
{
    echo "<script>alert('Your Reservation has been successfully deleted.');window.location.href='homepage.php';</script>";
    date_default_timezone_set('Asia/Kuala_Lumpur');
    $date=date("Y-m-d");
    $time = date("H:i:s"); // get date and time for when the reservation was made to store in staff_activity table
    $action="DELETE";
    $staffUsername=$_SESSION['getUserName'];
    /*updating staff activity table*/
    echo $cust_id;
    $sql="INSERT INTO staff_activity (recorded_time, recorded_date, staff_username, action, reservation_No, customer_ID)
            VALUES ('$time', '$date', '$staffUsername', '$action', '$reservation_No', '$cust_id');";
    if (mysqli_query($connect,$sql)==False){
        echo "<script>alert('Your actions have not been recorded due to a database error.');window.location.href='homepage.php';</script>";
    };

}
else
{
    echo "<script>alert('Your Reservation cannot be deleted due to an error.');window.location.href='reservation.php';</script>";
}
?>