<?PHP
include "functions1.php";
session_start();
$today = date('D-M-Y');
$tomorrow = date('D-M-Y', strtotime($today.'+1 day'));

$reservation_No=$_POST['edit_button'];
include ('connection.php');

// get reservation data using reservation_No
$getResData = "SELECT * FROM `reservation` WHERE reservation_No='$reservation_No'";
$getResDataResult = mysqli_query($connect, $getResData);
/*if update unsuccessful, return back to manage_page.php*/
if(mysqli_num_rows($getResDataResult)==1){
  $resData= mysqli_fetch_array($getResDataResult);
  $car_ID=$resData['car_ID'];
  $customer_ID=$resData['customer_ID'];
  $_SESSION['custid']=$customer_ID;
  $old_start=$resData['starting_Date'];
  $old_end=$resData['finishing_Date'];
  $old_rate=$resData['total_rate'];

}
else{
  echo '<script>window.location="manage_page.php"</script>';
}

// get car rate using car_ID
$getCarRate = "SELECT * FROM `car` WHERE car_ID='$car_ID'";
$getCarRateResult = mysqli_query($connect, $getCarRate);
if(mysqli_num_rows($getCarRateResult)==1){
  $carData= mysqli_fetch_array($getCarRateResult);
  $car_rate=$carData['price'];
}
else{
  echo '<script>window.location="manage_page.php"</script>';
}
$_SESSION['car_ID']=$car_ID;
$_SESSION['reservation_No']=$reservation_No;
?>


<!DOCTYPE html>
<head>
    <link rel="stylesheet" href="reservation .css">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="homepage2.css"/>
    <title>Make a Reservation</title>
    <link rel="icon" type="image/x-icon" href="image/godrive.jpeg">
</head>
<br><br>

<body>
     <div class=navigation>
            <nav>
                <img class=navlogo src="image/logo.PNG" alt="Logo">
                <a href="homepage.php" class="home">Home</a>
                <a href="index1.php" class="mreservation" >Make Reservation</a>
                <a href="manage_page.php" class="reservation">Reservations</a>
        <a href="staff_activity.php" class="reservation">Staff Activity</a>
            </nav>

        <li class="dropdown"> 
            <?php $var=$_SESSION['getUserName']; ?>
            <img class=user src="image/V.png" alt="user"></img>
                <div><?php echo $var; ?></div>
                    <ul class="ddlist"> 
                        <li><a href="key.php">New Staff</a></li>
                        <li><a href="loginpage.php">Log Out</a></li>
                    </ul>
        </li>
        </div>
</body>
<!--update booking input form-->
<div class="form-group">
  <h1>Update Booking</h1><br>
    <table id="customers" width="40%">
      <?PHP
      /*display suggested dates for user to reserve between*/
        $query = "SELECT `starting_Date`,`finishing_Date` FROM `reservation` WHERE `car_ID`='$car_ID' AND (`reservation_No` NOT IN('$reservation_No')) ";
        $result = mysqli_query($connect, $query);
        while ($row = mysqli_fetch_assoc($result)) {
          echo "<tr><td>". date('D-M-Y', strtotime($row['starting_Date']))."</td><td>~</td><td>".date('D-M-Y', strtotime($row['finishing_Date'])) ."</td></tr>";
        }
      ?>
    </table>
      <form method="GET" action="complete_edit.php">
        <input type="hidden" name="reservation_No" value="<?PHP echo $_SESSION['reservation_No']; ?>"/>
        <input type="hidden" class="forminput" name="car_ID" value="<?PHP echo $car_ID; ?>"/>

            <div class="labels">
              <label for="old_start">Current start Date on:</label>
            </div>

            <div class="fields">
              <input type="date" name="old_start" id="old_start" class="form-control" value="<?PHP echo $old_start; ?>" readonly />
            </div>

            <div class="labels">
              <label for="old_end">Current end Date on:</label>

            <div class="fields">
              <input type="date" name="old_end" id="old_end" class="form-control" value="<?PHP echo $old_end; ?>" readonly />
            </div>

            <div class="labels">
              <label for="new_start">New start Date on:</label>
            </div>

            <div class="fields">
              <input type="date" name="new_start" id="new_start" min="<?PHP echo $today; ?>" class="form-control" required />
            </div>

            <div class="labels">
              <label for="new_end">New end Date on:</label>
            </div>

            <div class="fields">
              <input type="date" name="new_end" id="new_end" min="<?PHP echo  $tomorrow; ?>" class="form-control" required />
            </div>

          <button type="submit" class="button">Submit</button>
      </form>
    </div>
</div>