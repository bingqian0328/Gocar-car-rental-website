<?php session_start(); include "functions1.php" ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styles.css">
<link rel="stylesheet" href="homepage2.css"/> <!--for username on side with logo -->
	<title>Make reservation</title>
</head>
<body>
	   <div class=navigation>
            <nav>
                <img class=navlogo src="image/logo.PNG" alt="Logo">
                <a href="homepage.php" class="home">Home</a>
                <a href="index1.php" class="mreservation" >Make Reservation</a>
                <a href="manage_page.php" class="reservation">Reservations</a>
                <a href="staff_activity.php" class="reservation">Staff Activity</a>
            </nav>

        <li class="dropdown"> 
            <?php $var=$_SESSION['getName']; ?>
            <img class=user src="image/V.png" alt="user"></img>
                <div><?php echo $var; ?></div>
                    <ul class="ddlist"> 
                        <li><a href="key.php">New Staff</a></li>
                        <li><a href="loginpage.php">Log Out</a></li>
                    </ul>
        </li>
        </div>
<!--input part of the filter section of the make reservation page-->
	<div class="page">
		<div class="left">
		<form method="post">
			<h2>Enter your requirements:</h2>
			<br>
			<p>Choose a type:</p>
			<br>
			<select name="products" id="products">
				<!--dropdown menu for choosing type of car-->
				<option <?php if(isset($_POST['products']) && $_POST['products']=='All Types') echo "selected='selected'"; ?> value="All Types">All Types</option>
				<option <?php if(isset($_POST['products']) && $_POST['products']=='Luxurious') echo "selected='selected'"; ?> value="Luxurious">Luxurious</option>
				<option <?php if(isset($_POST['products']) && $_POST['products']=='Sports') echo "selected='selected'"; ?> value="Sports">Sports</option>
				<option <?php if(isset($_POST['products']) && $_POST['products']=='Classics') echo "selected='selected'"; ?> value="Classics">Classics</option>
			</select>
			<br>
			<br>
    		<label>
    			Pick up Date:
    			<input type="date" id="PickUpDate" value="<?php echo $_POST['PickUpDate']??''; ?>" name="PickUpDate" required>
    		</label>
    		<br>
    		<br>
    		<label>
    			Drop off Date:
    			<input type="date" id="DropoffDate" name="DropoffDate" value="<?php echo $_POST['DropoffDate']??''; ?>" required> 
    		</label>
    		<br>
    		<br>
    		<button type="submit" name="filterbutton">Filter</button>
    	</form>
		</div>
		<div class="right">
			<h2>
				<?php
				/*change the header on right side of page from 'All Cars' to 'Cars Available' when filter button is clicked*/
			 		if(isset($_POST['filterbutton'])){
			 			echo "Cars Available";
			 		}else{
			 			echo "All Cars";
			 		}
			 	?>
			 	
			 </h2>
			<div class="product-wrapper">
			<?php
				if(isset($_POST['filterbutton'])){ 
					/*store today's date in a variable for dates validation later*/
					$today=date('Y-m-d');
					$products=[];
					$car_Type = $_POST['products']; /*name for drop down menu is products */
					$pickupdate = $_POST['PickUpDate'];
					$dropoffdate = $_POST['DropoffDate'];
					define("saved_car_type",$car_Type);
					$mysqli = connect();
					$_SESSION['products']=saved_car_type;
					$_SESSION['PickUpDate']=$pickupdate;
					$_SESSION['DropoffDate']=$dropoffdate;
					/*dates validation: dates entered should not be before today, and pickupdate<=dropoffdate*/
					if ($_SESSION['PickUpDate']>$_SESSION['DropoffDate'] || $_SESSION['PickUpDate']<$today || $_SESSION['DropoffDate']<$today){
						echo "<script>alert('Invalid dates entered.')</script>";
					}else{
						/*after user enters requirements get the filtered cars available as per user requirements*/
						/*if empty reservations table, display all products according to given category*/
						$empty = noreservations();
						if ($empty==True){
							$products = getProductsByCategory(saved_car_type);
						}else{
							$products = getProductsByDate(saved_car_type, $pickupdate, $dropoffdate);
						}
						$head="Cars Available";
						if (!empty($products)){
							foreach ($products as $product) {
								?>
									<div class="product">
										<div class="left">
											<img src="<?php echo $product['img'] ?>" alt="">
										</div>
										<div class="right">
											<p class="car_type"><?php echo $product['car_Type'] ?></p>
											<p class="car_name"><?php echo $product['car_Model'] ?></p>
											<p class="price"><?php echo 'RM ' . $product['price'] . ' per day'?></p>
											<form method = "post" action="index1.php">
												<input type="submit" name ="rentbutton" id = "<?php echo $product['car_ID'] ?>" value="<?php echo 'Rent car '.$product['car_ID'] ?>"></input>
											</form>
										</div>
									</div>
								<?php
							}
						}
						if (empty($products)){
							echo "No cars available.";
						}
					}
				}else{
					/*display all cars in the beginning, before the user enters their requirements*/
					$products = getAllProducts();
					foreach ($products as $product){
					?>
						<div class="product">
							<div class="left">
								<img src="<?php echo $product['img'] ?>" alt="">
							</div>
							<div class="right">
								<p class="car_type"><?php echo $product['car_Type'] ?></p>
								<p class="car_name"><?php echo $product['car_Model'] ?></p>
								<p class="price"><?php echo 'RM ' . $product['price'] . ' per day'?></p>
							</div>
						</div>
					<?php
				}
				}
				/*when rent button clicked, send user's chosen car's id to reservation.php page to store in reservations table*/
				if(isset($_POST['rentbutton']))
				{
					$car_id=str_replace("Rent car ","",$_POST['rentbutton']);
					$_SESSION['CARID'] = $car_id;
					echo '<script>window.location="reservation.php"</script>';
				}

			?>
			</div>
		</div>
	</div>

</body>
</html>

