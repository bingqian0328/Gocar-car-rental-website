<?php 
	function connect(){
		$conn = new mysqli('localhost', 'root','', 'COMP1044_database');
		if($conn->connect_errno != 0){
			return $mysqli->connect_error;
		}else{
			$conn->set_charset("utf8mb4");	
		}
		return $conn;
	}
	function getAllProducts(){ /*get all cars for display in the beginning*/
		$mysqli = connect();
		$result_Array = $mysqli->query("SELECT * FROM car");
		while($row = $result_Array->fetch_assoc()){
			$products[] = $row;
		}
		return $products;
	}

	function getProductsByDate($car_Type, $startdate, $endate){/*get all cars of the given type, available at the given dates*/
		$mysqli = connect();
		$products=[];
		if ($car_Type == "All Types"){

			$res = $mysqli->query("SELECT DISTINCT car.car_ID, car.car_Type, car.car_Model, car.price, car.img FROM car, reservation WHERE car.car_ID NOT IN (SELECT car.car_ID FROM car, reservation WHERE (car.car_ID = reservation.car_ID AND reservation.starting_Date<='$endate' AND reservation.finishing_Date>='$startdate'));");
		}else{
			$res = $mysqli->query("SELECT DISTINCT car.car_ID, car.car_Type, car.car_Model, car.price, car.img FROM car, reservation WHERE car.car_ID NOT IN (SELECT car.car_ID FROM car, reservation WHERE (car.car_ID = reservation.car_ID AND reservation.starting_Date<='$endate' AND reservation.finishing_Date>='$startdate'))AND car.car_Type = '$car_Type';");
		}
		while($row = $res->fetch_assoc()){
			$products[] = $row;
		}
		return $products;

	}
	function getProductsByCategory($car_Type){ /*get cars of the given type*/
		$mysqli = connect();
		$products=[];
		if ($car_Type == "All Types"){

			$res = $mysqli->query("SELECT car_ID, car_Type, car_Model, price, img FROM car;");
		}else{
			$res = $mysqli->query("SELECT car_ID, car_Type, car_Model, price, img FROM car WHERE car_Type = '$car_Type';");
		}
		while($row = $res->fetch_assoc()){
			$products[] = $row;
		}
		return $products;

	}
	/*returns boolean -  shows if customer already in the database*/
	function CustomerExists($cust_ID){
		$mysqli = connect();
		$products=[];
		$res = $mysqli->query("SELECT customer_Name FROM customer_detail WHERE customer_ID = '$cust_ID';");
		while($row = $res->fetch_assoc()){
			$products[] = $row;
		}
		if (empty($products)){
			return False;
		}else{
			return True;
		}

	}
	function userNameExists($userName){
		/*to inform user if their username is already being used*/
		$mysqli = connect();
		$products=[];
		$res = $mysqli->query("SELECT staff_username FROM staff_detail WHERE staff_username = '$userName';");
		while($row = $res->fetch_assoc()){
			$products[] = $row;
		}
		if (empty($products)){
			return False;
		}else{
			return True;
		}

	}
	function fetchPrice($car_id){
		/*fetch price to calculate total rate*/
		$mysqli=connect();
		$res = $mysqli->query("SELECT price FROM car WHERE car_ID = '$car_id';");
		$row = $res->fetch_assoc();
		return $row['price'];

	}
	function StaffExists($username,$password){ // for login page, verifying if the staff is already stored in database
		$mysqli = connect();
		$products=[];
		$res = $mysqli->query("SELECT staff_username FROM staff_detail WHERE staff_username='$username' AND password='$password';");
		while($row = $res->fetch_assoc()){
			$products[] = $row;
		}
		if (empty($products)){
			return False;
		}else{
			return True;
		}

	}
	function getCustID($resNo){
		/*fetch customer id to store in staff activity table*/
		$mysqli=connect();
		$res = $mysqli->query("SELECT customer_ID FROM reservation WHERE reservation_No = '$resNo';");
		$row = $res->fetch_assoc();
		return $row['customer_ID'];


	}
	function getName($username){
		/*fetch actual name of user to store in staff_detail table*/
		$mysqli=connect();
		$res = $mysqli->query("SELECT staff_name FROM staff_detail WHERE staff_username = '$username';");
		$row = $res->fetch_assoc();
		return $row['staff_name'];
	}
	
	function noreservations(){ 
		/*if no reservations have been made, all cars are available and only need to check car type in filter, so this function checks if reservation table is empty before calling function getProductsByCategory*/
		$mysqli = connect();
		$res="SELECT * FROM reservation";
		$result=$mysqli->query($res);
		if ($result->num_rows==0){
			return True;
		}else{
			return False;
		}
	}
?>
