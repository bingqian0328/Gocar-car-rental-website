<?PHP
include "functions1.php";
 session_start();
$host = "localhost";
$user = "root";
$password = "";
$db = "COMP1044_database";

$conn = new mysqli($host, $user, $password, $db);
include ('connection.php');
if (!(empty($_GET['new_start']) or empty($_GET['new_end'])))
{
    $car_ID=$_GET['car_ID'];
    $today=date('Y-m-d');
    $reservation_No=$_GET['reservation_No'];
    $new_start = $_GET['new_start'];
    $new_end = $_GET['new_end'];
    $cust_id=$_SESSION['custid'];
    $edit = "SELECT * FROM `reservation` WHERE (`car_ID`='$car_ID') AND (`finishing_Date` >= '$new_start' AND `starting_Date`<='$new_end') AND (`reservation_No` NOT IN('$reservation_No'))";
    if($new_end<=$new_start || $new_start<$today || $new_end<$today) // date validation for new dates
    {
        echo "<script>alert('Invalid date');window.location.href='manage_page.php';</script>";
    }
    else
    {
        $search = mysqli_query($connect,$edit);
        if(mysqli_num_rows($search)>0)
        {    
            echo "<script>alert('Sorry, the car is not available on the chosen date.');window.location.href='edit_booking.php';</script>";
        } 
        else
        {    
            /*extract car details from car table and make changes to reservation table*/
        $duration = ceil((strtotime($new_end)-strtotime($new_start))/(86400));
        
        $process = "select* from car where car_ID = '$car_ID' limit 1 ";
        
        $search = mysqli_query($connect,$process);
        
        if(mysqli_num_rows($search)==1)
        {
            $record= mysqli_fetch_array($search);
        }
        // change the total rate after dates are changed
        $total=date_diff(date_create($new_start),date_create($new_end));
        $calcdiff=$total->format("%a");
        if ($calcdiff==0){
            $calcdiff=1; // if the car returns on on the same day it was reserved, the rate is the same as for one day.
        }
        $total_rate=$calcdiff*fetchPrice($car_ID);
        
        $new="UPDATE `reservation` SET `starting_Date`='$new_start',`finishing_Date`='$new_end',`total_rate`='$total_rate' WHERE `reservation_No`='$reservation_No'";
        $updated = mysqli_query($connect,$new);
        echo "<script>alert('Reservation changed.');window.location.href='homepage.php';</script>";
        date_default_timezone_set('Asia/Kuala_Lumpur');
        $date=date("Y-m-d");
        $time = date("H:i:s");
        $action="UPDATE";
        $staffUsername=$_SESSION['getUserName'];
        $sql="INSERT INTO staff_activity (recorded_time, recorded_date, staff_username, action, reservation_No, customer_ID)
            VALUES ('$time', '$date', '$staffUsername', '$action', '$reservation_No', '$cust_id');";
        if ($conn->query($sql) === FALSE) {
            echo "Connection error. Actions not recorded.";
        }
        } 
    }
}
?>
